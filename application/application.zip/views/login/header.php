<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="<?php echo base_url('assets/'); ?>images/godrej-logo.png">

        <title>Godrej Marketplace</title>

        <!-- Bootstrap 4.0-->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/bootstrap/dist/css/bootstrap.min.css">

        <!-- theme style -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/style.css">

        <!-- Admin skins -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/skin_color.css">

        <!-- daterange picker -->	
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/bootstrap-daterangepicker/daterangepicker.css">

        <!-- bootstrap datepicker -->	
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

        <!-- iCheck for checkboxes and radio inputs -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_plugins/iCheck/all.css">

        <!-- Bootstrap Color Picker -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css">

        <!-- Bootstrap time Picker -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_plugins/timepicker/bootstrap-timepicker.min.css">

        <!-- Bootstrap select -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/bootstrap-select/dist/css/bootstrap-select.css">

        <!-- Bootstrap tagsinput -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.css">

        <!-- Bootstrap touchspin -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.css">

        <!-- Select2 -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/select2/dist/css/select2.min.css">

        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/bootstrap/dist/css/bootstrap.css">

         

        <!-- DashboardX Admin skins -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/skin_color.css">

        <!-- weather weather -->
        <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor_components/weather-icons/weather-icons.css">  


    </head>