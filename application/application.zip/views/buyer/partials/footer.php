<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
            <li class="nav-item">
                <a class="nav-link" href="#">
                    For website assistance contact : <?php echo ASSISTANCE_EMAIL; ?> | <?php echo ASSISTANCE_PHONE; ?>
                </a>
            </li>
        </ul>
    </div>
    &copy; 2022 <a href="#">Godrej Marketplace</a>. All Rights Reserved.
</footer>