<!DOCTYPE html>
<html lang="en">

    <?php $this->load->view('buyer/partials/header'); ?>

    <body class="hold-transition light-skin sidebar-mini theme-blueindigo onlyheader">

        <div class="wrapper">

            <div class="art-bg">
                <img src="<?php echo base_url('assets/'); ?>images/art1.svg" alt="" class="art-img light-img">
                <img src="<?php echo base_url('assets/'); ?>images/art2.svg" alt="" class="art-img dark-img">
                <img src="<?php echo base_url('assets/'); ?>images/art-bg.svg" alt="" class="wave-img light-img">
                <img src="<?php echo base_url('assets/'); ?>images/art-bg2.svg" alt="" class="wave-img dark-img">
            </div>

            <?php $this->load->view('buyer/partials/navbar'); ?>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <div class="container-full clearfix position-relative">	

                    <?php $this->load->view('buyer/partials/sidebar'); ?>

                    <!-- Main content -->
                    <section class="content">

                        <!-- Content Header (Page header) -->	  
                        <div class="content-header">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-block">
                                    <h3 class="page-title br-0">Dashboard</h3>
                                    <h5>Awarded data FY(22-23)</h5>
                                </div>
                                <div class="right-title d-md-block d-none">
                                    <div class="d-flex justify-content-end">
                                        <div class="d-md-flex mr-20 ml-10 d-none">
                                            <div class="chart-text mr-10">
                                                <h6 class="mb-0"><small>THIS MONTH</small></h6>
                                                <h4 class="mt-0 text-primary">$12,125</h4>
                                            </div>
                                            <div class="spark-chart">
                                                <div id="thismonth"><canvas width="60" height="35" style="display: inline-block; width: 60px; height: 35px; vertical-align: top;"></canvas></div>
                                            </div>
                                        </div>
                                        <div class="d-md-flex ml-10 d-none">
                                            <div class="chart-text mr-10">
                                                <h6 class="mb-0"><small>LAST YEAR</small></h6>
                                                <h4 class="mt-0 text-danger">$22,754</h4>
                                            </div>
                                            <div class="spark-chart">
                                                <div id="lastyear"><canvas width="60" height="35" style="display: inline-block; width: 60px; height: 35px; vertical-align: top;"></canvas></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-3 col-md-6 col-12">
                                <div class="box">
                                    <div class="box-body text-center">
                                        <i class="ti-wallet font-size-30"></i>
                                        <h2 class="font-weight-200">232</h2>
                                        <h3 class="text-danger font-weight-700">Vendors</h3>
                                        <p><small>Well, the way they make shows.</small></p>
                                    </div>
                                    <div class="box-body bg-lightest">
                                        <p class="mb-0">This is standard panel footer</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 col-12">
                                <div class="box">
                                    <div class="box-body">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <p class="mb-0">USERS ACTIVITY</p>
                                                <h2 class="font-weight-200 mt-0">748</h2>
                                            </div>
                                            <div>
                                                <i class="ti-share font-size-40"></i>
                                            </div>
                                        </div>
                                        <p class="font-weight-600 mb-2">Buyer users</p>
                                        <div class="progress progress-xxs mb-10">
                                            <div class="progress-bar progress-bar-danger progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                                <span class="sr-only">40% Complete (success)</span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <small>Pages / Visit</small>
                                                <h4 class="mb-0">7.80</h4>
                                            </div>

                                            <div class="col-6">
                                                <small>% New Visits</small>
                                                <h4 class="mb-0">76.43%</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box-body bg-lightest">
                                        <p class="mb-0">This is standard panel footer</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 col-12">
                                <div class="box">
                                    <div class="box-body">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <p class="mb-0">PAGE VIEWS</p>
                                                <h2 class="text-danger font-weight-200">458k+</h2>
                                            </div>
                                            <div>
                                                <i class="ti-desktop font-size-40"></i>
                                            </div>
                                        </div>
                                        <p class="font-weight-600 mb-2">Buyer users</p>
                                        <p style="padding-bottom: 3px;"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</small></p>
                                    </div>
                                    <div class="box-body bg-lightest">
                                        <p class="mb-0">This is standard panel footer</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 col-12">
                                <div class="box">
                                    <div class="box-body">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <p class="mb-0">Stage One</p>

                                            </div>
                                            <div>
                                                <i class="ti-server font-size-40"></i>
                                            </div>
                                        </div>
                                        <div id="linearea" class="mb-5">1,3,5,4,6,8,7,9,7,8,10,16,14,10</div>
                                        <div class="row">
                                            <div class="col-6">
                                                <small>Today</small>
                                                <h4 class="mb-0">$458,00</h4>
                                            </div>

                                            <div class="col-6">
                                                <small>Last week</small>
                                                <h4 class="mb-0">$1485 <i class="ti-arrow-up text-danger"></i> </h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box-body bg-lightest">
                                        <p class="mb-0">This is standard panel footer</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-7 col-12">
                                <div class="box">
                                    <div class="box-header with-border">
                                        <h4 class="box-title">By Users</h4>
                                    </div>
                                    <!-- /.box-header -->
                                    <div class="box-body py-0">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        <td><i class="fa fa-chrome mr-2 text-danger font-size-16"></i>Chrome</td>
                                                        <td>5126<small class="text-muted">(59%)</small></td>
                                                        <td>55.55%</td><td>458<small class="text-muted">(84%)</small></td>
                                                    </tr>								
                                                    <tr>
                                                        <td><i class="fa fa-firefox mr-2 text-blue font-size-16"></i>Firefox</td>
                                                        <td>1124<small class="text-muted">(36%)</small></td>
                                                        <td>21.77%</td><td>189<small class="text-muted">(45%)</small></td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-internet-explorer mr-2 text-warning font-size-16"></i>Internet-Explorer</td>
                                                        <td>2015<small class="text-muted">(28%)</small></td><td>31.87%</td>
                                                        <td>875<small class="text-muted">(82%)</small></td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-opera mr-2 text-danger font-size-16"></i>Opera</td>
                                                        <td>1842<small class="text-muted">(29%)</small></td><td>34.55%</td>
                                                        <td>428<small class="text-muted">(58%)</small></td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fa fa-safari mr-2 text-info font-size-16"></i>Safari</td>
                                                        <td>3512<small class="text-muted">(37%)</small></td>
                                                        <td>41%</td><td>399<small class="text-muted">(94%)</small></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                </div>
                            </div>
                            <div class="col-xl-5 col-12">
                                <div class="box">					
                                    <div class="box-body">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <h1 class="mb-0 mt-5">7,485</h1>
                                                <p>Ext. Records</p>                                
                                            </div>
                                            <div>
                                                <div id="barchart4"></div>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-hover mb-0">
                                                <tbody>
                                                    <tr>
                                                        <th><i class="mdi mdi-circle text-success"></i></th>
                                                        <td><i class="fa fa-facebook-square text-facebook font-size-16"></i></td>
                                                        <td><span>548</span></td>
                                                        <td>55% <i class="mdi mdi-arrow-up"></i></td>
                                                    </tr>
                                                    <tr>
                                                        <th><i class="mdi mdi-circle text-info"></i></th>
                                                        <td><i class="fa fa-twitter-square text-twitter font-size-16"></i></td>
                                                        <td><span>845</span></td>
                                                        <td>25% <i class="mdi mdi-arrow-up"></i></td>
                                                    </tr>
                                                    <tr>
                                                        <th><i class="mdi mdi-circle text-warning"></i></th>
                                                        <td><i class="fa fa-instagram text-instagram font-size-16"></i></td>
                                                        <td><span>425</span></td>
                                                        <td>18% <i class="mdi mdi-arrow-down"></i></td>
                                                    </tr>
                                                    <tr>
                                                        <th><i class="mdi mdi-circle"></i></th>
                                                        <td><i class="fa fa-pinterest-square text-pinterest font-size-16"></i></td>
                                                        <td><span>412</span></td>
                                                        <td>15% <i class="mdi mdi-arrow-down"></i></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="box">
                                    <div class="box-header with-border">
                                        <h4 class="box-title">Summary</h4>
                                        <div class="box-controls pull-right">
                                            <select class="custom-select">
                                                <option value="0" selected="">Monthly</option>
                                                <option value="1">Daily</option>
                                                <option value="2">Weekly</option>
                                                <option value="3">Yearly</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="box-body">
                                        <div class="row">
                                            <div class="col-lg-9">
                                                <div id="dayreport"></div>
                                            </div>
                                            <div class="col-lg-3">
                                                <h1 class="mb-0 mt-4">$7,745.6</h1>
                                                <h6 class="font-light text-muted">This Month Earnings</h6>
                                                <h3 class="mt-4 mb-0">4,421</h3>
                                                <h6 class="font-light text-muted">This Month Sales</h6>
                                                <a class="waves-effect waves-light btn btn-info my-3" href="javascript:void(0)">Previous Month Summary</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box-footer">
                                        <div class="row mb-0">
                                            <div class="col-xl-3 col-md-6">
                                                <div class="d-flex align-items-center">
                                                    <div class="mr-2"><span class="text-primary font-size-60"><i class="mdi mdi-wallet"></i></span></div>
                                                    <div><span>Account Balance</span>
                                                        <h3 class="my-0">$12,8547.53</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-3 col-md-6">
                                                <div class="d-flex align-items-center">
                                                    <div class="mr-2"><span class="text-success font-size-60"><i class="mdi mdi-star-circle"></i></span></div>
                                                    <div><span>Referral Program</span>
                                                        <h3 class="my-0">$7458.08</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-3 col-md-6">
                                                <div class="d-flex align-items-center">
                                                    <div class="mr-2"><span class="text-info font-size-60"><i class="mdi mdi-shopping"></i></span></div>
                                                    <div><span>Total Sales</span>
                                                        <h3 class="my-0">7854</h3></div>
                                                </div>
                                            </div>
                                            <div class="col-xl-3 col-md-6">
                                                <div class="d-flex align-items-center">
                                                    <div class="mr-2"><span class="text-danger font-size-60"><i class="mdi mdi-currency-usd"></i></span></div>
                                                    <div><span>Sales Earnings</span>
                                                        <h3 class="my-0">$12,985.90</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-6 col-12">
                                <div class="box mb-lg-0">
                                    <div class="box-header with-border">
                                        <h4 class="box-title">Finance Stats</h4>
                                    </div>
                                    <div class="box-body p-0 pb-5">
                                        <div class="media-list bb-1 bb-dashed border-light">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <p class="font-size-16">
                                                        <a class="hover-primary" href="#"><strong>Payment</strong></a>
                                                    </p>
                                                    <span class="font-size-12">Mauris dignissim lectus ut ipsum</span>
                                                </div>
                                                <div class="media-right">
                                                    <span class="font-weight-500 font-size-16 text-primary">+118%</span>
                                                </div>
                                            </div>							  
                                        </div>
                                        <div class="media-list bb-1 bb-dashed border-light">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <p class="font-size-16">
                                                        <a class="hover-primary" href="#"><strong>Logistics</strong></a>
                                                    </p>
                                                    <span class="font-size-12">Proin sit amet nibh ultricies, sagittis ipsum non</span>
                                                </div>
                                                <div class="media-right">
                                                    <span class="font-weight-500 font-size-16 text-info">$74,123</span>
                                                </div>
                                            </div>							  
                                        </div>
                                        <div class="media-list bb-1 bb-dashed border-light">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <p class="font-size-16">
                                                        <a class="hover-primary" href="#"><strong>Marginal Sale</strong></a>
                                                    </p>
                                                    <span class="font-size-12">Morbi egestas augue et hendrerit ultrices</span>
                                                </div>
                                                <div class="media-right">
                                                    <span class="font-weight-500 font-size-16 text-info">+895%</span>
                                                </div>
                                            </div>							  
                                        </div>
                                        <div class="media-list bb-1 bb-dashed border-light">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <p class="font-size-16">
                                                        <a class="hover-primary" href="#"><strong>Expenses</strong></a>
                                                    </p>
                                                    <span class="font-size-12">Donec vel justo efficitur, lobortis velit </span>
                                                </div>
                                                <div class="media-right">
                                                    <span class="font-weight-500 font-size-16 text-danger">-12%</span>
                                                </div>
                                            </div>							  
                                        </div>
                                        <div class="media-list bb-1 bb-dashed border-light">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <p class="font-size-16">
                                                        <a class="hover-primary" href="#"><strong>Transactions</strong></a>
                                                    </p>
                                                    <span class="font-size-12">Aenean gravida erat scelerisque, maximus </span>
                                                </div>
                                                <div class="media-right">
                                                    <span class="font-weight-500 font-size-16 text-primary">$12,525</span>
                                                </div>
                                            </div>							  
                                        </div>
                                        <div class="media-list">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <p class="font-size-16">
                                                        <a class="hover-primary" href="#"><strong>Lorem ipsum</strong></a>
                                                    </p>
                                                    <span class="font-size-12">Curabitur eu tellus in ligula condimentum</span>
                                                </div>
                                                <div class="media-right">
                                                    <span class="font-weight-500 font-size-16 text-success">+21%</span>
                                                </div>
                                            </div>							  
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-12">					
                                <div class="box">
                                    <div class="box-body">
                                        <div id="chartdiv1" class="w-p100 h-200"></div>
                                        <h4 class="text-center mb-15">Traffic Source</h4>
                                        <p class="text-center text-fade">65 (Mid level)</p>
                                    </div>
                                </div>
                                <div class="box mb-0">
                                    <div class="box-body bg-img py-70" style="background-image: url(../images/gallery/thumb/12.jpg)" data-overlay="5">
                                        <blockquote class="blockquote blockquote-inverse no-border no-margin">
                                            <p class="font-size-22">Donec vitae leo dignissim, sodales purus et, egestas est.</p>
                                            <footer>Someone famous in <cite title="Source Title">Source Title</cite></footer>
                                        </blockquote>
                                    </div>
                                    <div class="box-body">
                                        <h4>volutpat metus commodo.</h4>
                                        <div class="flexbox">
                                            <div class="time">Few seconds ago</div>
                                            <ul class="flexbox">
                                                <li><a href="#">845 <i class="fa fa-comment-o"></i></a></li>
                                                <li><a href="#">85K <i class="fa fa-heart-o"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>			
                    </section>
                    <!-- /.content -->
                </div>
            </div>
            <!-- /.content-wrapper -->
            <?php $this->load->view('buyer/partials/footer'); ?>

            <!-- Control Sidebar -->
            <?php $this->load->view('buyer/partials/control'); ?>
            <!-- /.control-sidebar -->

            <!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
            <div class="control-sidebar-bg"></div>

        </div>
        <!-- ./wrapper -->

        <?php $this->load->view('buyer/partials/scripts'); ?>

    </body>
</html>