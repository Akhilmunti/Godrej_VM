  <style type="text/css">
.btn{
 width: 50px;
}
.btn-sm{
    margin-top: 5px;
}
.subbutton{
      width: 100px !important;
    margin-bottom: 22px !important;
    float: right;
}
  </style>
                    <!-- Main content -->
                    <section class="content">

                        <!-- Content Header (Page header) -->	  
                        <div class="content-header">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-block">
                                    <h3 class="page-title br-0">PQ Score</h3>
                                </div>
                            </div>
                        </div>

                          <div class="row">
                            <div class="col-12">
                                <!-- Step wizard -->
                                <div class="box box-default">
                                    <div class="box-body pb-0">
                                        <form action="" method="POST">
                                            <div class="table-responsive">
                                              <table id="example" class="table table-bordered table-hover display nowrap margin-top-10 w-p100">
                                                <thead>
                                                    <tr>
                                                        <th colspan="7" style="text-align:center" >Assesment sheet for pre-qualifaction of contarctors</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td> S.N. </td>
                                                        <td>Croteroa</td>
                                                        <td>Weogjatge</td>
                                                        <td>SCORING GUIDE</td>
                                                        <td>System Generated PQ Score </td>
                                                        <td>Manual PQ Score Edited by CM</td>
                                                        <td>Reasons for Corrections in Score – mandatory by CM</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="5">General</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowspan="3">1</td>
                                                        <td rowspan="3">EXPERINCE OF SIMILAR WORK</td> 
                                                        <td rowspan="3">10</td>
                                                        <td>More than 10 completed works in last 5 years</td>
                                                        <td >10</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>

                                                    </tr>
                                                    <tr>
                                                         <td>More than 5 completed works in last 5 years</td>
                                                        <td >5</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                         <td>Less than 5 completed works in last 5 years</td>
                                                        <td >3</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowspan="3">2</td>
                                                        <td rowspan="3"> PRE-QUALIFICATION/EXISTING ASSOCIATION WITH OTHER CLIENTS</td> 
                                                        <td rowspan="3">10</td>
                                                        <td>Registered with or having work order from 4  and more reputed developers</td>
                                                        <td >10</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>

                                                    </tr>
                                                    <tr>
                                                         <td>Registered with or having work order from 2 and more reputed developers</td>
                                                        <td >6</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                         <td>Registered with or having work order from only 1 reputed developers</td>
                                                        <td >3</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                     <tr>
                                                        <td rowspan="3">3</td>
                                                        <td rowspan="3"> COMMENDATION /TIMELY COMPLETION CERTIFICATES FROM CUSTOMERS WITH CONTACT DETAILS IN THE LAST 5 YEARS</td> 
                                                        <td rowspan="3">10</td>
                                                        <td>More than 6</td>
                                                        <td >10</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>

                                                    </tr>
                                                    <tr>
                                                         <td>3 to  6</td>
                                                        <td >6</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                         <td>1 to 2</td>
                                                        <td >3</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="5">Financial</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                     <tr>
                                                        <td> 4 </td>
                                                        <td>Working Capital - Current ratio</td>
                                                        <td>10</td>
                                                        <td colspan="2">> 1.5 - 10 marks ,
                                                             1.5 to 1.15 - 7 marks 
                                                             1.14 to 1 - 5 marks
                                                            < 1  0 marks
                                                        </td> 
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td> 5</td>
                                                        <td>Profit Ratio (Current year Vs. Last 3 years average profit)</td>
                                                        <td>10</td>
                                                        <td colspan="2">> 1.25- 10 marks
                                                                        <1.25 > 1.15 5 marks
                                                                        < 1.15 > 1- 3 mark
                                                                        < 1 0 marks

                                                        </td> 
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td> 6</td>
                                                        <td>Profit Ratio (Current year Vs. Last 3 years average profit)</td>
                                                        <td>10</td>
                                                        <td colspan="2">> 1.20 - 10 marks
                                                                        1.2 to 1.05 - 7 marks
                                                                        < 1.05 > 1 - 3 mark
                                                                        < 1  0 marks
                                                        </td> 
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                     <tr>
                                                        <td colspan="5">Technical</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowspan="2"> 7</td>
                                                        <td rowspan="2">QUALITY & SAFETY MANAGEMENT SYSTEM </td>
                                                        <td rowspan="2">10</td>
                                                        <td>BOTH ISO: 9001 CERTIFIED & 45001 CERTIFIED
                                                        </td> 
                                                        <td >10</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                       <td>EITHER ISO 9001 OR 45001 CERTIFIED
                                                        </td> 
                                                        <td>5</td>   
                                                        <td><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowspan="2" > 8</td>
                                                        <td rowspan="2">SITE VISIT REPORT (with GO-NOGO recommendation)</td>
                                                        <td >10</td>
                                                        <td colspan="2">Quality and safety performance as seen at site
                                                        </td> 
                                                        <td >this is calculated from above table</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                         
                                                    </tr>
                                                    <tr>
                                                        <td >20</td>
                                                        <td colspan="2">Resource mobilization, quality of manpower, documentation, progress, invoicing, client feedback, subcontractor feedback etc.
                                                        </td> 
                                                        <td >this is calculated from above table</td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td> </td>
                                                        <td>TOTAL</td>
                                                        <td >100</td>
                                                        <td colspan="2">MINIMUM QUALIFYING SCORE - 50
                                                        </td> 
                                                        <td ><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                         
                                                    </tr>
                                                     <tr>
                                                        <td colspan="5">FINACIAL LIMIT CATEGORIZATION </td>
                                                         
                                                        <td ><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                         
                                                    </tr>
                                                     <tr>
                                                        <td colspan="5">0.5 times the average turnover of last 3 years </td>
                                                         
                                                        <td ><input type="text" name="" class="form-control"></td>
                                                        <td><input type="text" name="" class="form-control"></td>
                                                         
                                                    </tr>
                                                </tbody>   
                                              </table>

                                            </div> 
                                            <div class="text-xs-right" >
                                                <button type="submit" class="btn btn-primary subbutton btn-info">Submit</button>
                                           </div>
                                        </form>
                                         
                                    </div>
                                </div>
                                <!-- /.box -->
                            </div>
                        </div>
                    </section>
                    <!-- /.content -->
                </div>
            </div> 
}
}
}
