  <style type="text/css">
.btn{
 width: 50px;
}
.btn-sm{
    margin-top: 5px;
}
.subbutton{
      width: 100px !important;
    margin-bottom: 22px !important;
    float: right;
}
  </style>
                    <!-- Main content -->
                    <section class="content">

                        <!-- Content Header (Page header) -->	  
                        <div class="content-header">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-block">
                                    <h3 class="page-title br-0">Site Visit Report</h3>
                                </div>
                            </div>
                        </div>

                          <div class="row">
                            <div class="col-12">
                                <!-- Step wizard -->
                                <div class="box box-default">
                                    <div class="box-body pb-0">
                                        <div class="table-responsive">
                                            <table id="example" class="table table-bordered table-hover display nowrap margin-top-10 w-p100">
                                                <thead>
                                                    <tr>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            NAME OF THE CONTRACTOR
                                                        </td>
                                                        <td>
                                                           <input type="text" name="" class="form-control">
                                                        </td>
                                                        
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                           NAME OF THE SITE VISTED
                                                        </td>
                                                        <td>
                                                            <input type="text" name=""  class="form-control">
                                                        </td>
                                                       
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            CATEGORY/TYPE/NATURE OF WORKS for PQ
                                                        </td>
                                                        <td>
                                                             <input type="text" name=""  class="form-control">
                                                        </td>
                                                         
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            NAME & DESIGNATION OF ASSESSOR 1
                                                        </td>
                                                        <td>
                                                             <input type="text" name=""  class="form-control">
                                                        </td>
                                                         
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                           NAME & DESIGNATION OF ASSESSOR 2
                                                        </td>
                                                        <td>
                                                             <input type="text" name=""  class="form-control">
                                                        </td>
                                                         
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                           NAME & DESIGNATION OF ASSESSOR 3
                                                        </td>
                                                        <td>
                                                             <input type="text" name=""  class="form-control">
                                                        </td>
                                                         
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                           DATE OF VISIT
                                                        </td>
                                                        <td>
                                                             <input type="text" name=""  class="form-control">
                                                        </td>
                                                         
                                                    </tr>

                                                </tbody>   
                                            </table>
                                        </div> 
                                         <div class="text-xs-right" >
                                                <button type="submit" class="btn btn-primary subbutton btn-info">Submit</button>
                                        </div> 
                                    </div>
                                </div>
                                <!-- /.box -->
                            </div>
                        </div>
                    </section>
                    <!-- /.content -->
                </div>
            </div> 
}
}
